package com.example.qrchatapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
