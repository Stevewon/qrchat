=================================
QRChat v1.0.8 Android APK
=================================

📱 파일 정보
- 파일명: qrchat_v1.0.8.apk
- 크기: 27.8 MB (ARM64)
- 최소 Android 버전: Android 5.0 (API 21) 이상
- 권장: 대부분의 최신 Android 기기에서 실행 가능

✨ 주요 변경사항 (v1.0.8)
1. 📱 프로필 화면 개선
   - "My QR Code" 메뉴를 AppBar의 톱니바퀴 옆으로 이동
   - QR 코드 아이콘 클릭으로 빠른 접근 가능
   - 하단 메뉴 리스트 정리

2. 🎨 닉네임/비밀번호 찾기 UI 개선
   - QR 주소 입력란 깔끔한 디자인으로 변경
   - 불필요한 여러 줄 입력 제거
   - 더 명확한 힌트 텍스트 (https://securet.kr/...)
   - 둥근 모서리와 포커스 효과 추가

3. 🎥 동영상 썸네일 표시 (v1.0.7 유지)
4. 📋 친구 목록 가나다순 정렬 (v1.0.7 유지)

📝 설치 방법
1. APK 파일을 Android 기기로 전송
2. 파일 관리자 앱에서 APK 파일 터치
3. "알 수 없는 소스" 설치 허용 (필요 시)
4. 설치 진행
5. 앱 열기

⚠️ Firebase Storage 규칙 확인
동영상 썸네일 표시를 위해 Firebase Storage 규칙이 올바르게 설정되어 있는지 확인하세요:
→ https://console.firebase.google.com/project/qrchat-b7a67/storage/rules

🔗 관련 링크
- GitHub 저장소: https://github.com/Stevewon/qrchat
- 웹 관리자 대시보드: https://qrchat-b7a67.web.app/admin_dashboard.html

🛠️ 빌드 정보
- 빌드 날짜: 2026-02-14
- 버전: 1.0.8 (빌드 108)
- Flutter: 3.27.3
- Dart: 3.6.1
