====================================
QRChat v1.0.6 Android APK
====================================

🆕 v1.0.6 중요 업데이트:
✅ 동영상 썸네일 무한 로딩 문제 해결!
   - 로딩 스피너가 계속 도는 버그 수정
   - 썸네일 캐싱으로 성능 향상
   - 타임아웃 10초 설정

📱 설치 방법:
1. "qrchat_v1.0.6.apk" 파일을 휴대폰으로 전송
2. 파일 실행
3. "알 수 없는 출처" 허용
4. 설치 완료!

📝 파일 정보:
- 파일명: qrchat_v1.0.6.apk
- 크기: 27.8 MB
- 지원: 대부분의 Android 기기 (ARM64)
- 최소: Android 5.0 이상

🆕 전체 기능:
✅ 친구 목록 가나다순 정렬 (한글 → 영어)
✅ 동영상 썸네일 실제 프레임 표시
✅ QR 주소로 닉네임/비밀번호 찾기
✅ 회원가입 시 닉네임 중복 체크
✅ 차단된 사용자 로그인 차단

⚠️ Firebase Storage 규칙 확인:
   https://console.firebase.google.com/project/qrchat-b7a67/storage/rules
   "allow read, write: if true;" 설정 필요!

🔗 링크:
- GitHub: https://github.com/Stevewon/qrchat
- 웹 대시보드: https://qrchat-b7a67.web.app/admin_dashboard.html

====================================
빌드: 2026-02-14
버전: 1.0.6
====================================
