QRChat v1.0.10 Android APK 설치 가이드
=========================================

파일 정보:
- 파일명: qrchat_v1.0.10.apk
- 크기: 27.8 MB
- 최소 Android 버전: 5.0 (API 21)

주요 변경사항 (v1.0.10):
✅ QKEY 적립량 변경
   - 이전: 5분당 10 QKEY 적립
   - 이후: 5분당 2 QKEY 적립
   - 목적: QKEY 가치 상승 및 적립 균형 조정

✅ 기존 거래 내역 업데이트
   - 과거 모든 적립 거래 10 QKEY → 2 QKEY로 변경
   - 총 58개 거래 내역 업데이트 완료
   - 사용자별 거래 내역 일관성 유지

기존 기능 유지 (v1.0.9):
✓ 스티커팩 탭 구분 (카카오톡 스타일)
✓ 그룹 채팅 이미지/스티커 크기 일관성
✓ 동영상 썸네일 생성 (HTTP 다운로드 + 로컬 캐싱)
✓ 친구 목록 가나다 정렬
✓ QR 주소로 닉네임/비밀번호 찾기
✓ 회원가입 닉네임 중복 체크
✓ 차단 사용자 로그인 방지
✓ QR 코드 재가입 방지
✓ My QR Code 아이콘 (프로필 화면 우상단)
✓ 단일 라인 QR 주소 입력

설치 방법:
1. 휴대폰에서 이 ZIP 파일을 다운로드하여 압축 해제
2. qrchat_v1.0.10.apk 파일 실행
3. "출처를 알 수 없는 앱 설치" 권한 허용 (필요 시)
4. 설치 진행

⚠️ 중요 사항:
- Firebase Storage 규칙이 read/write 허용으로 설정되어 있어야 합니다
- 규칙 설정 위치: https://console.firebase.google.com/project/qrchat-b7a67/storage/rules
- 규칙 예시:
  ```
  rules_version = '2';
  service firebase.storage {
    match /b/{bucket}/o {
      match /{allPaths=**} {
        allow read, write: if true;
      }
    }
  }
  ```
- 규칙 변경 후 "게시" 버튼 클릭 필수

📊 QKEY 적립 시스템 변경 내역:

┌─────────────────┬──────────┬──────────┐
│ 항목            │ 이전     │ 이후     │
├─────────────────┼──────────┼──────────┤
│ 5분당 적립량    │ 10 QKEY  │ 2 QKEY   │
│ 1시간 적립량    │ 120 QKEY │ 24 QKEY  │
│ 1일 적립량      │ 2,880 QKEY│ 576 QKEY│
│ 최소 출금 금액  │ 1,000    │ 1,000    │
│ 출금 단위       │ 1,000    │ 1,000    │
└─────────────────┴──────────┴──────────┘

💡 변경 이유:
1. QKEY 가치 상승 및 희소성 증가
2. 적립-출금 균형 조정
3. 장기 지속 가능성 확보
4. 사용자 활동 품질 향상 유도

🎨 스티커팩 관리:
- Firestore 컬렉션: sticker_packs
- 필드 구조:
  - pack_name: 스티커팩 이름 (예: "섹시녀", "멍청이")
  - stickers: 배열 (image_url, sticker_name)
  - created_at: 생성 시간 (최신순 정렬)
- 업로드 방법: Firebase Console > Firestore Database에서 직접 추가
- 앱을 재시작할 필요 없이 실시간으로 자동 반영됨

관련 링크:
- GitHub 저장소: https://github.com/Stevewon/qrchat
- 관리자 대시보드: https://qrchat-b7a67.web.app/admin_dashboard.html
- Firebase Console: https://console.firebase.google.com/project/qrchat-b7a67

빌드 정보:
- 빌드 날짜: 2026-02-14
- 버전: 1.0.10 (Build 110)
- Flutter: 3.27.3
- Dart: 3.6.1

테스트 가이드:
1. ✅ 앱 설치 및 v1.0.10 확인
2. ✅ 채팅 활동 후 QKEY 적립 확인 (2 QKEY)
3. ✅ QKEY 거래 내역 확인 (모든 적립이 2 QKEY)
4. ✅ 5분 타이머 작동 확인
5. ✅ 스티커팩 정상 작동 확인
