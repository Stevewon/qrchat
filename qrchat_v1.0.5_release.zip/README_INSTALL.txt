====================================
QRChat v1.0.5 Android APK
====================================

📱 설치 방법:

1. "qrchat_v1.0.5.apk" 파일을 휴대폰으로 전송
   (USB, 이메일, 클라우드 등)

2. 파일 실행

3. "알 수 없는 출처" 또는 "이 출처 허용" 클릭

4. 설치 진행

5. 완료!


📝 파일 정보:
- 파일명: qrchat_v1.0.5.apk
- 크기: 27.8 MB
- 지원: 대부분의 Android 기기 (ARM64)
- 최소: Android 5.0 이상


🆕 v1.0.5 새로운 기능:
✅ 친구 목록 가나다순 정렬 (한글 먼저 → 영어 나중)
✅ 동영상 썸네일 실제 프레임 표시
✅ QR 주소로 닉네임/비밀번호 찾기
✅ 회원가입 시 닉네임 중복 체크
✅ 차단된 사용자 로그인 차단

⚠️ 중요: Firebase Storage 규칙 수정 필요!
   https://console.firebase.google.com/project/qrchat-b7a67/storage/rules
   규칙을 "allow read, write: if true;"로 변경하세요!
   (썸네일 표시를 위해 필수!)


🔗 링크:
- GitHub: https://github.com/Stevewon/qrchat
- 웹 대시보드: https://qrchat-b7a67.web.app/admin_dashboard.html


====================================
빌드: 2026-02-14
버전: 1.0.5
====================================
