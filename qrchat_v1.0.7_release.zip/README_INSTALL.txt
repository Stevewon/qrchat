=================================
QRChat v1.0.7 Android APK
=================================

📱 파일 정보
- 파일명: qrchat_v1.0.7.apk
- 크기: 27.8 MB (ARM64)
- 최소 Android 버전: Android 5.0 (API 21) 이상
- 권장: 대부분의 최신 Android 기기에서 실행 가능

✨ 주요 변경사항 (v1.0.7)
1. 🎥 동영상 썸네일 표시 완전 수정
   - Firebase Storage URL에서 직접 썸네일 생성 실패 문제 해결
   - 동영상을 먼저 다운로드한 후 로컬 파일에서 썸네일 생성
   - 1:1 채팅 + 그룹 채팅 모두 적용
   - 로딩 스피너가 무한 반복되는 문제 해결
   
2. 📋 친구 목록 가나다순 정렬 (한글 → 영어)
3. 🔍 QR 주소 닉네임/비밀번호 찾기
4. ✅ 회원가입 시 닉네임 중복 체크
5. 🚫 차단된 사용자 로그인 차단
6. 🔐 QR 코드 재가입 방지

📝 설치 방법
1. APK 파일을 Android 기기로 전송
2. 파일 관리자 앱에서 APK 파일 터치
3. "알 수 없는 소스" 설치 허용 (필요 시)
4. 설치 진행
5. 앱 열기

⚠️ 중요: Firebase Storage 규칙 설정 필수!
썸네일이 표시되지 않을 경우:
→ https://console.firebase.google.com/project/qrchat-b7a67/storage/rules
→ 규칙을 다음과 같이 변경:

rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{allPaths=**} {
      allow read, write: if true;
    }
  }
}

→ "게시" 버튼 클릭 후 10초 대기
→ 앱 재시작 후 동영상 전송 테스트

🔗 관련 링크
- GitHub 저장소: https://github.com/Stevewon/qrchat
- 웹 관리자 대시보드: https://qrchat-b7a67.web.app/admin_dashboard.html

🛠️ 빌드 정보
- 빌드 날짜: 2026-02-14
- 버전: 1.0.7 (빌드 107)
- Flutter: 3.27.3
- Dart: 3.6.1
